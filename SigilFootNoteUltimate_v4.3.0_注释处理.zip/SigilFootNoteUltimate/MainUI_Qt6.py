# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'MainUI.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QButtonGroup, QCheckBox,
    QFormLayout, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QListWidgetItem, QMainWindow, QPushButton,
    QRadioButton, QSizePolicy, QSpacerItem, QTabWidget,
    QTextEdit, QVBoxLayout, QWidget)

from CustomClass import (SavedConfGroupBox, SavedConfListWidget, TemplateEdit_A, TemplateEdit_B,
    TemplateEdit_C)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(511, 572)
        MainWindow.setWindowTitle(u"epub\u6ce8\u91ca\u5904\u7406")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setEnabled(True)
        self.tab_1 = QWidget()
        self.tab_1.setObjectName(u"tab_1")
        self.verticalLayout_5 = QVBoxLayout(self.tab_1)
        self.verticalLayout_5.setSpacing(18)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.auto_gbox = QGroupBox(self.tab_1)
        self.auto_gbox.setObjectName(u"auto_gbox")
        self.auto_gbox.setMinimumSize(QSize(0, 90))
        self.auto_gbox.setMaximumSize(QSize(16777215, 90))
        self.auto_gbox.setTitle(u"\u81ea\u52a8\u8bc6\u522b")
        self.verticalLayout_4 = QVBoxLayout(self.auto_gbox)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.amzn_rbtn = QRadioButton(self.auto_gbox)
        self.buttonGroup_runtype = QButtonGroup(MainWindow)
        self.buttonGroup_runtype.setObjectName(u"buttonGroup_runtype")
        self.buttonGroup_runtype.addButton(self.amzn_rbtn)
        self.amzn_rbtn.setObjectName(u"amzn_rbtn")
        self.amzn_rbtn.setText(u"\u81ea\u52a8\u8bc6\u522b\u5e26\u8df3\u8f6c\u94fe\u63a5\u7684\u6ce8\u91ca")

        self.horizontalLayout_2.addWidget(self.amzn_rbtn)

        self.check_loss_cbox = QCheckBox(self.auto_gbox)
        self.check_loss_cbox.setObjectName(u"check_loss_cbox")
        self.check_loss_cbox.setChecked(True)

        self.horizontalLayout_2.addWidget(self.check_loss_cbox)


        self.verticalLayout_4.addLayout(self.horizontalLayout_2)


        self.verticalLayout_5.addWidget(self.auto_gbox)

        self.manual_gbox = QGroupBox(self.tab_1)
        self.manual_gbox.setObjectName(u"manual_gbox")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.manual_gbox.sizePolicy().hasHeightForWidth())
        self.manual_gbox.setSizePolicy(sizePolicy)
        self.manual_gbox.setTitle(u"\u624b\u52a8\u8bc6\u522b")
        self.verticalLayout_3 = QVBoxLayout(self.manual_gbox)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(-1, 12, -1, -1)
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setSpacing(7)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.regexp_rbtn = QRadioButton(self.manual_gbox)
        self.buttonGroup_runtype.addButton(self.regexp_rbtn)
        self.regexp_rbtn.setObjectName(u"regexp_rbtn")
        self.regexp_rbtn.setText(u"\u6b63\u5219\u8868\u8fbe\u5f0f\u641c\u7d22")

        self.horizontalLayout_5.addWidget(self.regexp_rbtn)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_3)

        self.preSearch_cbox = QCheckBox(self.manual_gbox)
        self.preSearch_cbox.setObjectName(u"preSearch_cbox")

        self.horizontalLayout_5.addWidget(self.preSearch_cbox)

        self.horizontalSpacer_4 = QSpacerItem(15, 20, QSizePolicy.Fixed, QSizePolicy.Minimum)

        self.horizontalLayout_5.addItem(self.horizontalSpacer_4)

        self.noRef_mode_cbox = QCheckBox(self.manual_gbox)
        self.noRef_mode_cbox.setObjectName(u"noRef_mode_cbox")

        self.horizontalLayout_5.addWidget(self.noRef_mode_cbox)


        self.verticalLayout_3.addLayout(self.horizontalLayout_5)

        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setLabelAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.formLayout.setHorizontalSpacing(6)
        self.formLayout.setVerticalSpacing(8)
        self.formLayout.setContentsMargins(-1, 2, -1, 5)
        self.preSearch_lbl = QLabel(self.manual_gbox)
        self.preSearch_lbl.setObjectName(u"preSearch_lbl")
        self.preSearch_lbl.setText(u"\u9884\u641c\u7d22")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.preSearch_lbl)

        self.preSearch_le = QLineEdit(self.manual_gbox)
        self.preSearch_le.setObjectName(u"preSearch_le")
        self.preSearch_le.setText(u"")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.preSearch_le)

        self.regexp_noteref_le = QLineEdit(self.manual_gbox)
        self.regexp_noteref_le.setObjectName(u"regexp_noteref_le")
        self.regexp_noteref_le.setText(u"")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.regexp_noteref_le)

        self.regexp_footnote_lbl = QLabel(self.manual_gbox)
        self.regexp_footnote_lbl.setObjectName(u"regexp_footnote_lbl")
        self.regexp_footnote_lbl.setText(u"\u6ce8\u91ca Footnote")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.regexp_footnote_lbl)

        self.regexp_footnote_le = QLineEdit(self.manual_gbox)
        self.regexp_footnote_le.setObjectName(u"regexp_footnote_le")
        self.regexp_footnote_le.setText(u"")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.regexp_footnote_le)

        self.regexp_noteref_lbl = QLabel(self.manual_gbox)
        self.regexp_noteref_lbl.setObjectName(u"regexp_noteref_lbl")
        self.regexp_noteref_lbl.setText(u"\u6ce8\u6807 NoteRef")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.regexp_noteref_lbl)


        self.verticalLayout_3.addLayout(self.formLayout)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.var_mode_cbox = QCheckBox(self.manual_gbox)
        self.var_mode_cbox.setObjectName(u"var_mode_cbox")
        self.var_mode_cbox.setEnabled(True)

        self.horizontalLayout_3.addWidget(self.var_mode_cbox)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.span_mode_cbox = QCheckBox(self.manual_gbox)
        self.span_mode_cbox.setObjectName(u"span_mode_cbox")
        self.span_mode_cbox.setEnabled(True)

        self.horizontalLayout_3.addWidget(self.span_mode_cbox)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)


        self.verticalLayout_5.addWidget(self.manual_gbox)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, -1, -1)
        self.subpos_gbox = QGroupBox(self.tab_1)
        self.subpos_gbox.setObjectName(u"subpos_gbox")
        self.subpos_gbox.setTitle(u"\u6ce8\u91ca\u66ff\u6362\u4f4d\u7f6e")
        self.verticalLayout_2 = QVBoxLayout(self.subpos_gbox)
        self.verticalLayout_2.setSpacing(8)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.subpos_default_rbtn = QRadioButton(self.subpos_gbox)
        self.buttonGroup_subpos = QButtonGroup(MainWindow)
        self.buttonGroup_subpos.setObjectName(u"buttonGroup_subpos")
        self.buttonGroup_subpos.addButton(self.subpos_default_rbtn)
        self.subpos_default_rbtn.setObjectName(u"subpos_default_rbtn")
        self.subpos_default_rbtn.setText(u"\u539f\u6587\u4f4d\u7f6e")

        self.verticalLayout_2.addWidget(self.subpos_default_rbtn)

        self.subpos_end_rbtn = QRadioButton(self.subpos_gbox)
        self.buttonGroup_subpos.addButton(self.subpos_end_rbtn)
        self.subpos_end_rbtn.setObjectName(u"subpos_end_rbtn")
        self.subpos_end_rbtn.setText(u"\u6ce8\u91ca\u79fb\u5230\u9875\u9762\u672b\u5c3e")

        self.verticalLayout_2.addWidget(self.subpos_end_rbtn)

        self.subpos_noteref_rbtn = QRadioButton(self.subpos_gbox)
        self.buttonGroup_subpos.addButton(self.subpos_noteref_rbtn)
        self.subpos_noteref_rbtn.setObjectName(u"subpos_noteref_rbtn")
        self.subpos_noteref_rbtn.setText(u"\u6ce8\u91ca\u63d2\u5165\u5230\u6ce8\u6807\u6240\u5728\u4e0b\u4e00\u6bb5")

        self.verticalLayout_2.addWidget(self.subpos_noteref_rbtn)


        self.horizontalLayout.addWidget(self.subpos_gbox)

        self.groupBox = SavedConfGroupBox(self.tab_1)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setTitle(u"\u914d\u7f6e\u6a21\u677f")
        self.verticalLayout_10 = QVBoxLayout(self.groupBox)
        self.verticalLayout_10.setSpacing(8)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.saved_conf = SavedConfListWidget(self.groupBox)
        self.saved_conf.setObjectName(u"saved_conf")
        self.saved_conf.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.saved_conf.setDragEnabled(True)
        self.saved_conf.setDragDropMode(QAbstractItemView.InternalMove)
        self.saved_conf.setSelectionMode(QAbstractItemView.ExtendedSelection)

        self.verticalLayout_10.addWidget(self.saved_conf)


        self.horizontalLayout.addWidget(self.groupBox)


        self.verticalLayout_5.addLayout(self.horizontalLayout)

        self.tabWidget.addTab(self.tab_1, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.verticalLayout_6 = QVBoxLayout(self.tab_2)
        self.verticalLayout_6.setSpacing(6)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(15, -1, 15, -1)
        self.label_7 = QLabel(self.tab_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setStyleSheet(u"")
        self.label_7.setText(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:6px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:120%;\"><span style=\" color:#333341;\">\u3000\u3000\u6ce8\u91ca\u66ff\u6362\u6a21\u677f\u672c\u8d28\u662f\u4e00\u6bb5\u53ef\u52a0\u5165\u7279\u6b8a\u53d8\u91cf\u7684\u66ff\u6362\u5b57\u7b26\u4e32\uff0c\u5efa\u8bae\u6309\u7167HTML\u8bed\u6cd5\u6765\u5199\uff0c\u4ee5\u514d\u66ff\u6362\u540e\u7834\u574f\u9875\u9762\u7684HTML\u7ed3\u6784\u3002</span></p>\n"
"<p style=\" margin-top:6px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:130%;\"><span style=\" font-weight:600; color:#333341;\">\u7279\u6b8a\u53d8"
                        "\u91cf<br /></span><span style=\" color:#0000ff;\">[href] </span><span style=\" color:#333341;\">\u81ea\u52a8\u94fe\u63a5  </span><span style=\" color:#0000ff;\">[ref]  </span><span style=\" color:#333341;\">\u53bb\u6807\u7b7e\u6ce8\u6807\u5185\u5bb9  </span><span style=\" color:#0000ff;\">[pos] </span><span style=\" color:#333341;\">\u9875\u5c3e\u8282\u70b9\u6807\u8bb0 <br /></span><span style=\" color:#0000ff;\">[id]   </span><span style=\" color:#333341;\">\u81ea\u52a8\uff29\uff24  </span><span style=\" color:#0000ff;\">[note] </span><span style=\" color:#333341;\">\u53bb\u6807\u7b7e\u6ce8\u91ca\u5185\u5bb9  </span><span style=\" color:#0000ff;\">[NUM] </span><span style=\" color:#333341;\">\u5168\u5c40\u8ba1\u6570\u5668</span><br /><span style=\" color:#0000ff;\">[HREF]</span> <span style=\" color:#333341;\">\u5b8c\u6574\u94fe\u63a5</span>  <span style=\" color:#0000ff;\">[tgtfile]</span>  <span style=\" color:#333341;\">\u76ee\u6807\u6587\u4ef6\u540d</span>  <span style=\" color:#0000ff;\">[num]</span> <s"
                        "pan style=\" color:#333341;\">\u9875\u5185\u8ba1\u6570\u5668</span></p></body></html>")
        self.label_7.setTextFormat(Qt.RichText)
        self.label_7.setWordWrap(True)

        self.verticalLayout_6.addWidget(self.label_7)

        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setSpacing(6)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.label_8 = QLabel(self.tab_2)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setText(u"\u6ce8\u6807\u6a21\u677f")

        self.verticalLayout_8.addWidget(self.label_8, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.noteref_te_auto = TemplateEdit_A(self.tab_2)
        self.noteref_te_auto.setObjectName(u"noteref_te_auto")
        self.noteref_te_auto.setLineWrapMode(QTextEdit.NoWrap)
        self.noteref_te_auto.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6ce8\u6807\u793a\u4f8b\u6a21\u677f --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;sup&gt;&lt;a class=&quot;duokan-footnote&quot; href=&quot;[href]&quot; id=&quot;[id]&quot;&gt;&lt;img src=&quot;../Images/no"
                        "te.png&quot;/&gt;&lt;/a&gt;&lt;/sup&gt;</span></p></body></html>")
        self.noteref_te_auto.setAcceptRichText(False)
        self.noteref_te_auto.setProperty("tabStopWidth", 18)

        self.verticalLayout_8.addWidget(self.noteref_te_auto)

        self.label_9 = QLabel(self.tab_2)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setText(u"\u6ce8\u91ca\u6a21\u677f")

        self.verticalLayout_8.addWidget(self.label_9, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.note_te_auto = TemplateEdit_A(self.tab_2)
        self.note_te_auto.setObjectName(u"note_te_auto")
        self.note_te_auto.setLineWrapMode(QTextEdit.NoWrap)
        self.note_te_auto.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6ce8\u91ca\u793a\u4f8b\u6a21\u677f --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;li class=&quot;duokan-footnote-item&quot; id=&quot;[id]&quot;&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0"
                        "px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">	&lt;a href=&quot;[href]&quot;&gt;[note]&lt;/a&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;/li&gt;</span></p></body></html>")
        self.note_te_auto.setAcceptRichText(False)
        self.note_te_auto.setProperty("tabStopWidth", 18)

        self.verticalLayout_8.addWidget(self.note_te_auto)

        self.tailnode1_lbl = QLabel(self.tab_2)
        self.tailnode1_lbl.setObjectName(u"tailnode1_lbl")
        self.tailnode1_lbl.setText(u"\u9875\u5c3e\u8282\u70b9\u6a21\u677f")

        self.verticalLayout_8.addWidget(self.tailnode1_lbl, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.foot_te_auto = TemplateEdit_C(self.tab_2)
        self.foot_te_auto.setObjectName(u"foot_te_auto")
        self.foot_te_auto.setLineWrapMode(QTextEdit.NoWrap)
        self.foot_te_auto.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6b64\u6a21\u677f\u53ef\u5ffd\u7565\u4e0d\u586b\uff0c\u586b\u5199\u65f6\u5fc5\u987b\u5e26[pos]\u53d8\u91cf\u3002 --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;hr class=&quot;footnote&quot;/&gt;</span></p>\n"
""
                        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;ol class=&quot;duokan-footnote-content&quot;&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">	[pos]</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;/ol&gt;</span></p></body></html>")
        self.foot_te_auto.setAcceptRichText(False)
        self.foot_te_auto.setProperty("tabStopWidth", 18)

        self.verticalLayout_8.addWidget(self.foot_te_auto)


        self.verticalLayout_6.addLayout(self.verticalLayout_8)

        self.tabWidget.addTab(self.tab_2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.verticalLayout_7 = QVBoxLayout(self.tab_3)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(15, -1, 15, -1)
        self.label_11 = QLabel(self.tab_3)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setStyleSheet(u"")
        self.label_11.setText(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'SimSun'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:6px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:120%;\"><span style=\" color:#333341;\">\u3000\u3000\u6ce8\u91ca\u66ff\u6362\u6a21\u677f\u672c\u8d28\u662f\u4e00\u6bb5\u53ef\u52a0\u5165\u7279\u6b8a\u53d8\u91cf\u7684\u66ff\u6362\u5b57\u7b26\u4e32\uff0c\u5efa\u8bae\u6309\u7167HTML\u8bed\u6cd5\u6765\u5199\uff0c\u4ee5\u514d\u66ff\u6362\u540e\u7834\u574f\u9875\u9762\u7684HTML\u7ed3\u6784\u3002</span></p>\n"
"<p style=\" margin-top:6px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:130%;\"><span style=\" font-weight:600; color:#333341;\">\u7279\u6b8a\u53d8"
                        "\u91cf<br /></span><span style=\" color:#0000ff;\">[href] </span><span style=\" color:#333341;\">\u81ea\u52a8\u94fe\u63a5  </span><span style=\" color:#0000ff;\">[r1]-[r9] </span><span style=\" color:#333341;\">\u6ce8\u6807\u6355\u83b7\u7ec4  </span><span style=\" color:#0000ff;\">[pos]</span><span style=\" color:#333341;\"> \u9875\u5c3e\u8282\u70b9\u6807\u8bb0<br /></span><span style=\" color:#0000ff;\">[id]   </span><span style=\" color:#333341;\">\u81ea\u52a8\uff29\uff24  </span><span style=\" color:#0000ff;\">[n1]-[n9] </span><span style=\" color:#333341;\">\u6ce8\u91ca\u6355\u83b7\u7ec4  </span><span style=\" color:#0000ff;\">[NUM] </span><span style=\" color:#333341;\">\u5168\u5c40\u8ba1\u6570\u5668</span><br /><span style=\" color:#0000ff;\">[HREF]</span> <span style=\" color:#333341;\">\u5b8c\u6574\u94fe\u63a5</span>  <span style=\" color:#0000ff;\">[tgtfile]</span> <span style=\" color:#333341;\">\u76ee\u6807\u6587\u4ef6\u540d</span>  <span style=\" color:#0000ff;\">[num]</span> <span style=\" color:#"
                        "333341;\">\u9875\u5185\u8ba1\u6570\u5668</span></p></body></html>")
        self.label_11.setTextFormat(Qt.RichText)
        self.label_11.setWordWrap(True)

        self.verticalLayout_7.addWidget(self.label_11)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setSpacing(6)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.label_18 = QLabel(self.tab_3)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setText(u"\u6ce8\u6807\u6a21\u677f")

        self.verticalLayout_11.addWidget(self.label_18, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.noteref_te_man = TemplateEdit_B(self.tab_3)
        self.noteref_te_man.setObjectName(u"noteref_te_man")
        self.noteref_te_man.setLineWrapMode(QTextEdit.NoWrap)
        self.noteref_te_man.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6ce8\u6807\u793a\u4f8b\u6a21\u677f --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;sup&gt;&lt;a class=&quot;duokan-footnote&quot; href=&quot;[href]&quot; id=&quot;[id]&quot;&gt;&lt;img src=&quot;../Images/no"
                        "te.png&quot;/&gt;&lt;/a&gt;&lt;/sup&gt;</span></p></body></html>")
        self.noteref_te_man.setAcceptRichText(False)
        self.noteref_te_man.setProperty("tabStopWidth", 18)

        self.verticalLayout_11.addWidget(self.noteref_te_man)

        self.label_19 = QLabel(self.tab_3)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setText(u"\u6ce8\u91ca\u6a21\u677f")

        self.verticalLayout_11.addWidget(self.label_19, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.note_te_man = TemplateEdit_B(self.tab_3)
        self.note_te_man.setObjectName(u"note_te_man")
        self.note_te_man.setLineWrapMode(QTextEdit.NoWrap)
        self.note_te_man.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6ce8\u91ca\u793a\u4f8b\u6a21\u677f --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;li class=&quot;duokan-footnote-item&quot; id=&quot;[id]&quot;&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0"
                        "px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">	&lt;a href=&quot;[href]&quot;&gt;[r1]&lt;/a&gt; [n1]</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;/li&gt;</span></p></body></html>")
        self.note_te_man.setAcceptRichText(False)
        self.note_te_man.setProperty("tabStopWidth", 18)

        self.verticalLayout_11.addWidget(self.note_te_man)

        self.tailnode2_lbl = QLabel(self.tab_3)
        self.tailnode2_lbl.setObjectName(u"tailnode2_lbl")
        self.tailnode2_lbl.setText(u"\u9875\u5c3e\u8282\u70b9\u6a21\u677f")

        self.verticalLayout_11.addWidget(self.tailnode2_lbl, 0, Qt.AlignHCenter|Qt.AlignBottom)

        self.foot_te_man = TemplateEdit_C(self.tab_3)
        self.foot_te_man.setObjectName(u"foot_te_man")
        self.foot_te_man.setLineWrapMode(QTextEdit.NoWrap)
        self.foot_te_man.setHtml(u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Microsoft YaHei UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;!-- \u6b64\u6a21\u677f\u53ef\u5ffd\u7565\u4e0d\u586b\uff0c\u586b\u5199\u65f6\u5fc5\u987b\u5e26[pos]\u53d8\u91cf\u3002 --&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;hr class=&quot;footnote&quot;/&gt;</span></p>\n"
""
                        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;ol class=&quot;duokan-footnote-content&quot;&gt;</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">	[pos]</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun';\">&lt;/ol&gt;</span></p></body></html>")
        self.foot_te_man.setAcceptRichText(False)
        self.foot_te_man.setProperty("tabStopWidth", 18)

        self.verticalLayout_11.addWidget(self.foot_te_man)


        self.verticalLayout_7.addLayout(self.verticalLayout_11)

        self.tabWidget.addTab(self.tab_3, "")

        self.verticalLayout.addWidget(self.tabWidget)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.readme_pbtn = QPushButton(self.centralwidget)
        self.readme_pbtn.setObjectName(u"readme_pbtn")
        self.readme_pbtn.setMinimumSize(QSize(55, 30))
        self.readme_pbtn.setMaximumSize(QSize(55, 16777215))
        self.readme_pbtn.setText(u"\u8bf4\u660e")

        self.horizontalLayout_4.addWidget(self.readme_pbtn)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer)

        self.comfirm_pbtn = QPushButton(self.centralwidget)
        self.comfirm_pbtn.setObjectName(u"comfirm_pbtn")
        self.comfirm_pbtn.setMinimumSize(QSize(0, 30))
        self.comfirm_pbtn.setText(u"\u6267\u884c")

        self.horizontalLayout_4.addWidget(self.comfirm_pbtn)

        self.save_pbtn = QPushButton(self.centralwidget)
        self.save_pbtn.setObjectName(u"save_pbtn")
        self.save_pbtn.setMinimumSize(QSize(0, 30))
        self.save_pbtn.setText(u"\u4fdd\u5b58")

        self.horizontalLayout_4.addWidget(self.save_pbtn)

        self.cancel_pbtn = QPushButton(self.centralwidget)
        self.cancel_pbtn.setObjectName(u"cancel_pbtn")
        self.cancel_pbtn.setMinimumSize(QSize(0, 30))

        self.horizontalLayout_4.addWidget(self.cancel_pbtn)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        MainWindow.setCentralWidget(self.centralwidget)
#if QT_CONFIG(shortcut)
        self.preSearch_lbl.setBuddy(self.preSearch_le)
        self.regexp_footnote_lbl.setBuddy(self.regexp_footnote_le)
        self.regexp_noteref_lbl.setBuddy(self.preSearch_le)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        self.check_loss_cbox.setText(QCoreApplication.translate("MainWindow", u"\u68c0\u67e5\u9057\u6f0f", None))
        self.preSearch_cbox.setText(QCoreApplication.translate("MainWindow", u"\u9884\u641c\u7d22", None))
        self.noRef_mode_cbox.setText(QCoreApplication.translate("MainWindow", u"\u884c\u5185\u5939\u6ce8", None))
        self.var_mode_cbox.setText(QCoreApplication.translate("MainWindow", u"\u6ce8\u6807\u6355\u83b7\u7ec4\u4f20\u627f\u7ed9\u6ce8\u91ca\u8868\u8fbe\u5f0f", None))
        self.span_mode_cbox.setText(QCoreApplication.translate("MainWindow", u"\u8de8\u9875\u6ce8\u91ca", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_1), QCoreApplication.translate("MainWindow", u"\u529f\u80fd\u8bbe\u7f6e", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"\u66ff\u6362\u6a21\u677f\u3010\u81ea\u52a8\u8bc6\u522b\u3011", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"\u66ff\u6362\u6a21\u677f\u3010\u624b\u52a8\u8bc6\u522b\u3011", None))
        self.cancel_pbtn.setText(QCoreApplication.translate("MainWindow", u"\u9000\u51fa", None))
        pass
    # retranslateUi

