import os

e = os.environ.get('SIGIL_QT_RUNTIME_VERSION', '6.5.2')
SIGIL_QT_MAJOR_VERSION = tuple(map(int, (e.split("."))))[0]

if SIGIL_QT_MAJOR_VERSION == 6:
    from PySide6 import QtWidgets,QtGui,QtCore
    import MainUI_Qt6 as MainUI
elif SIGIL_QT_MAJOR_VERSION == 5:
    from PyQt5 import QtWidgets,QtGui,QtCore
    import MainUI
    