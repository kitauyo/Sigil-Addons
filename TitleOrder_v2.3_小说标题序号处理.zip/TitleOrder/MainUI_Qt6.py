# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'MainUI.ui'
##
## Created by: Qt User Interface Compiler version 6.5.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QHBoxLayout,
    QLabel, QLayout, QLineEdit, QPushButton,
    QRadioButton, QSizePolicy, QSpacerItem, QVBoxLayout,
    QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(491, 323)
        font = QFont()
        font.setFamilies([u"\u5fae\u8f6f\u96c5\u9ed1"])
        Form.setFont(font)
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setSizeConstraint(QLayout.SetMinimumSize)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(-1, -1, -1, 6)
        self.label = QLabel(Form)
        self.label.setObjectName(u"label")
        sizePolicy = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        font1 = QFont()
        font1.setFamilies([u"\u5b8b\u4f53"])
        font1.setPointSize(12)
        font1.setBold(True)
        self.label.setFont(font1)

        self.horizontalLayout.addWidget(self.label)

        self.titletype_le_1 = QLineEdit(Form)
        self.titletype_le_1.setObjectName(u"titletype_le_1")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.titletype_le_1.sizePolicy().hasHeightForWidth())
        self.titletype_le_1.setSizePolicy(sizePolicy1)
        self.titletype_le_1.setMinimumSize(QSize(75, 0))

        self.horizontalLayout.addWidget(self.titletype_le_1)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Minimum)

        self.horizontalLayout.addItem(self.horizontalSpacer)

        self.label_3 = QLabel(Form)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font1)

        self.horizontalLayout.addWidget(self.label_3)

        self.fmt_comb_1 = QComboBox(Form)
        self.fmt_comb_1.addItem("")
        self.fmt_comb_1.addItem("")
        self.fmt_comb_1.addItem("")
        self.fmt_comb_1.setObjectName(u"fmt_comb_1")

        self.horizontalLayout.addWidget(self.fmt_comb_1)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(-1, -1, -1, 6)
        self.label_4 = QLabel(Form)
        self.label_4.setObjectName(u"label_4")
        sizePolicy.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy)
        self.label_4.setFont(font1)

        self.horizontalLayout_4.addWidget(self.label_4)

        self.titletype_le_2 = QLineEdit(Form)
        self.titletype_le_2.setObjectName(u"titletype_le_2")
        sizePolicy1.setHeightForWidth(self.titletype_le_2.sizePolicy().hasHeightForWidth())
        self.titletype_le_2.setSizePolicy(sizePolicy1)
        self.titletype_le_2.setMinimumSize(QSize(75, 0))

        self.horizontalLayout_4.addWidget(self.titletype_le_2)

        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Minimum, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)

        self.label_5 = QLabel(Form)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font1)

        self.horizontalLayout_4.addWidget(self.label_5)

        self.fmt_comb_2 = QComboBox(Form)
        self.fmt_comb_2.addItem("")
        self.fmt_comb_2.addItem("")
        self.fmt_comb_2.addItem("")
        self.fmt_comb_2.setObjectName(u"fmt_comb_2")
        self.fmt_comb_2.setEditable(False)

        self.horizontalLayout_4.addWidget(self.fmt_comb_2)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.label_7 = QLabel(Form)
        self.label_7.setObjectName(u"label_7")
        font2 = QFont()
        font2.setFamilies([u"\u6977\u4f53"])
        font2.setPointSize(11)
        self.label_7.setFont(font2)
        self.label_7.setStyleSheet(u"color:red;")

        self.verticalLayout.addWidget(self.label_7)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout.addItem(self.verticalSpacer)

        self.label_6 = QLabel(Form)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setFont(font1)

        self.verticalLayout.addWidget(self.label_6)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(-1, -1, -1, 6)
        self.whole_rbtn = QRadioButton(Form)
        self.buttonGroup = QButtonGroup(Form)
        self.buttonGroup.setObjectName(u"buttonGroup")
        self.buttonGroup.addButton(self.whole_rbtn)
        self.whole_rbtn.setObjectName(u"whole_rbtn")
        font3 = QFont()
        font3.setFamilies([u"\u5fae\u8f6f\u96c5\u9ed1"])
        font3.setPointSize(11)
        self.whole_rbtn.setFont(font3)
        self.whole_rbtn.setChecked(True)

        self.horizontalLayout_5.addWidget(self.whole_rbtn)

        self.selected_rbtn = QRadioButton(Form)
        self.buttonGroup.addButton(self.selected_rbtn)
        self.selected_rbtn.setObjectName(u"selected_rbtn")
        self.selected_rbtn.setFont(font3)

        self.horizontalLayout_5.addWidget(self.selected_rbtn)


        self.verticalLayout.addLayout(self.horizontalLayout_5)

        self.label_2 = QLabel(Form)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setFont(font1)

        self.verticalLayout.addWidget(self.label_2)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.direct_rbtn = QRadioButton(Form)
        self.buttonGroup_2 = QButtonGroup(Form)
        self.buttonGroup_2.setObjectName(u"buttonGroup_2")
        self.buttonGroup_2.addButton(self.direct_rbtn)
        self.direct_rbtn.setObjectName(u"direct_rbtn")
        sizePolicy2 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.direct_rbtn.sizePolicy().hasHeightForWidth())
        self.direct_rbtn.setSizePolicy(sizePolicy2)
        self.direct_rbtn.setFont(font3)
        self.direct_rbtn.setChecked(True)

        self.horizontalLayout_2.addWidget(self.direct_rbtn)

        self.reorder_rbtn = QRadioButton(Form)
        self.buttonGroup_2.addButton(self.reorder_rbtn)
        self.reorder_rbtn.setObjectName(u"reorder_rbtn")
        self.reorder_rbtn.setFont(font3)

        self.horizontalLayout_2.addWidget(self.reorder_rbtn)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setSpacing(12)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(-1, 6, -1, 5)
        self.comfirm_btn = QPushButton(Form)
        self.comfirm_btn.setObjectName(u"comfirm_btn")

        self.horizontalLayout_3.addWidget(self.comfirm_btn)

        self.cancel_btn = QPushButton(Form)
        self.cancel_btn.setObjectName(u"cancel_btn")

        self.horizontalLayout_3.addWidget(self.cancel_btn)


        self.verticalLayout.addLayout(self.horizontalLayout_3)


        self.retranslateUi(Form)

        self.fmt_comb_1.setCurrentIndex(1)
        self.fmt_comb_2.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"\u6807\u9898\u6392\u5e8f", None))
        self.label.setText(QCoreApplication.translate("Form", u"\u6807\u9898\u7c7b\u578b", None))
        self.titletype_le_1.setText(QCoreApplication.translate("Form", u"\u5377,\u90e8", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"\u8f6c\u5e8f\u53f7\u683c\u5f0f", None))
        self.fmt_comb_1.setItemText(0, QCoreApplication.translate("Form", u"\u963f\u62c9\u4f2f\u6570\u5b57", None))
        self.fmt_comb_1.setItemText(1, QCoreApplication.translate("Form", u"\u4e2d\u6587\u3010\u4e8c\u3007\u3007\u4e8c\u3011", None))
        self.fmt_comb_1.setItemText(2, QCoreApplication.translate("Form", u"\u4e2d\u6587\u3010\u4e8c\u5343\u96f6\u4e8c\u3011", None))

        self.label_4.setText(QCoreApplication.translate("Form", u"\u6807\u9898\u7c7b\u578b", None))
        self.titletype_le_2.setText(QCoreApplication.translate("Form", u"\u7ae0,\u8282,\u56de", None))
        self.label_5.setText(QCoreApplication.translate("Form", u"\u8f6c\u5e8f\u53f7\u683c\u5f0f", None))
        self.fmt_comb_2.setItemText(0, QCoreApplication.translate("Form", u"\u963f\u62c9\u4f2f\u6570\u5b57", None))
        self.fmt_comb_2.setItemText(1, QCoreApplication.translate("Form", u"\u4e2d\u6587\u3010\u4e8c\u3007\u3007\u4e8c\u3011", None))
        self.fmt_comb_2.setItemText(2, QCoreApplication.translate("Form", u"\u4e2d\u6587\u3010\u4e8c\u5343\u96f6\u4e8c\u3011", None))

        self.label_7.setText(QCoreApplication.translate("Form", u"\u6ce8: \u6807\u9898\u4ec5\u5339\u914d h1-h6 \u5143\u7d20\u7684\u5b57\u7b26\u4e32\uff0c\u975e h1-h6 \u5143\u7d20\n"
"    \u5185\u90e8\u7684\u5b57\u7b26\u4e32\u4e0d\u4f1a\u5339\u914d\u3002", None))
        self.label_6.setText(QCoreApplication.translate("Form", u"\u8bf7\u9009\u62e9\u5904\u7406\u8303\u56f4\uff1a", None))
        self.whole_rbtn.setText(QCoreApplication.translate("Form", u"\u6240\u6709\u9875\u9762", None))
        self.selected_rbtn.setText(QCoreApplication.translate("Form", u"\u9009\u4e2d\u9875\u9762", None))
        self.label_2.setText(QCoreApplication.translate("Form", u"\u8bf7\u9009\u62e9\u8f6c\u5316\u65b9\u5f0f\uff1a", None))
        self.direct_rbtn.setText(QCoreApplication.translate("Form", u"\u76f4\u63a5\u8f6c\u5316", None))
        self.reorder_rbtn.setText(QCoreApplication.translate("Form", u"\u91cd\u65b0\u6392\u5e8f", None))
        self.comfirm_btn.setText(QCoreApplication.translate("Form", u"\u786e\u8ba4", None))
        self.cancel_btn.setText(QCoreApplication.translate("Form", u"\u53d6\u6d88", None))
    # retranslateUi

