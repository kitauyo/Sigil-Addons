#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys,os
import re

from pyqt_import import QtCore, QtGui, QtWidgets, Ui_Form


RANGE = 0 #处理范围： 0 整本 1 选择范围
TITLETYPE_1 = '卷,部'
TITLETYPE_2 = '章,节,回'
TITLE_1_FMT = 2 #序号类型 0 阿拉伯数字 1 中文【二〇〇一】 2 中文【二千零一】
TITLE_2_FMT = 1 #序号类型 0 阿拉伯数字 1 中文【二〇〇一】 2 中文【二千零一】
ORDER_SERI_1 = 0
ORDER_SERI_2 = 0
RE_ORDER = False # 重排序

# 本脚本主要用于标题的序号转阿拉伯数字或中文数字，支持序号小于100000的数，超过100000则不进行转化。

MODE = 0 # 0 自动互转 1 阿拉伯转中文数字 2 中文转阿拉伯数字

#阿拉伯数字转中文数字
def arba_turn_cn(arab_num:str,cn_format:int)->str:
    ''' cn_format 参数 0   2001 --> 二千零一
        cn_fromat 参数 1   2001 --> 二〇〇一
    '''
    if not isinstance(arab_num,str) or arab_num == '':
        return ""
    test = re.match(r'\d+$',arab_num)
    if not test or len(test.group()) < len(arab_num):
        return arab_num
    for index in range(len(arab_num)):
        if arab_num[index] != '0':
            break
    arab_num = arab_num[index:]
    if cn_format == 1 and len(arab_num) >= 3:
        num_map = {'0':'〇','1':'一','2':'二','3':'三','4':'四','5':'五','6':'六','7':'七','8':'八','9':'九'}
        result = ''
        for num in arab_num:
            result += num_map[num]
        return result

    l = len(arab_num)
    if l >= 6:
        return arab_num #超过十万则返回阿拉伯数字
    unit = ['','','十','百','千','万']
    num_zh = ['零','一','二','三','四','五','六','七','八','九']
    result = ''
    last_n = -1
    for n in arab_num:
        n = int(n)
        if n > 0:
            result += num_zh[n] + unit[l]
        elif last_n != 0:
            result += num_zh[n]
        l -= 1
        last_n = n
    if result[0:2] == "一十":
        result = result[1:]
    if len(result) > 1 and result[-1] == '零':
        result = result[:-1]
    return result

# 中文数字转阿拉伯
# 支持写法：
# 写法一： 一万三千零一十一、壹萬〇伍佰
# 写法二： 两千四百二十、两萬
# 写法三： 二〇〇一、三五一〇、贰零贰零

CN_TO_ARAB_MAP = {'两':2,'百':100,'佰':100,'千':1000,'仟':1000,'万':10000,'萬':10000}
CN_NUM_SIM = '零一二三四五六七八九十'
CN_NUM_TRA = '〇壹贰叁肆伍陆柒捌玖拾'
for index in range(11):
    CN_TO_ARAB_MAP[CN_NUM_SIM[index]] = index
    CN_TO_ARAB_MAP[CN_NUM_TRA[index]] = index

def cn_turn_arab(cn_num:str) -> str:
    if not isinstance(cn_num,str) or cn_num == '':
        return ""

    if len(cn_num) == 1 and cn_num in '一二三四五六七八九十壹贰叁肆伍陆柒捌玖拾〇零':
        arab_num = CN_TO_ARAB_MAP[cn_num]
        return str(arab_num)

    test = re.match(r'[一二两三四五六七八九十壹贰叁肆伍陆柒捌玖拾][一二两三四五六七八九十百千万壹贰叁肆伍陆柒捌玖拾佰仟萬〇零]+$',cn_num)

    if test is None or len(test.group()) < len(cn_num):
        return cn_num
    
    if re.match(r'[一二三四五六七八九壹贰叁肆伍陆柒捌玖〇零]+$',cn_num):
        test_type = 2
    else:
        test_type = 1

    # 中文数字类型为“二〇〇一”、“一三四五”这类的简单写法
    if test_type == 2:
        arab_num = ''
        for num in cn_num:
            digit = CN_TO_ARAB_MAP[num]
            arab_num += str(digit)
        return arab_num

    # 中文数字类型为“一千四百零三”这类正常写法
    arab_num = 0
    base_digit = 1
    rate = 1
    for index in range(len(cn_num)):
        num = cn_num[index]
        if num in '一二两三四五六七八九壹贰叁肆伍陆柒捌玖':
            base_digit = CN_TO_ARAB_MAP[num]
        elif num in '十百千万拾佰仟萬':
            rate = CN_TO_ARAB_MAP[num]
            arab_num += base_digit * rate
        elif num in '零〇':
            if cn_num[index-1] in '一二三四五六七八九壹贰叁肆伍陆柒捌玖':
                arab_num += base_digit * 10
    if cn_num[-1] in '一二三四五六七八九壹贰叁肆伍陆柒捌玖':
        arab_num += CN_TO_ARAB_MAP[cn_num[-1]]
    return str(arab_num)

def auto_turn_num(num_str:str,turn_type:int):
    '''
    turn_type 0 阿拉伯数字 1 中文【二〇〇一】 2 中文【二千零一】
    '''
    if turn_type == 0:
        t_num = cn_turn_arab(num_str)
    elif turn_type == 1:
        num_str = cn_turn_arab(num_str)
        t_num = arba_turn_cn(num_str, 1)

    elif turn_type == 2:
        num_str = cn_turn_arab(num_str)
        t_num = arba_turn_cn(num_str, 0)
    return t_num

def main_process(bk):
    ttype_list_1 = TITLETYPE_1.replace(' ', '').split(',')
    ttype_list_2 = TITLETYPE_2.replace(' ', '').split(',')
    titletype = ''.join(ttype_list_1+ttype_list_2)
    is_head = False
    def turn_title_num(match):
        global is_head
        def func_(m):
            global ORDER_SERI_1,ORDER_SERI_2
            title_type = m.group(2)
            
            if title_type in ttype_list_1:
                if not RE_ORDER:
                    num_str = m.group(1)
                    t_num = auto_turn_num(num_str, TITLE_1_FMT)
                else:
                    if is_head:
                        ORDER_SERI_1 += 1
                        num_str = str(ORDER_SERI_1)
                    else:
                        num_str = str(ORDER_SERI_1 + 1)
                    t_num = auto_turn_num(num_str, TITLE_1_FMT)

            elif title_type in ttype_list_2:

                if not RE_ORDER:
                    num_str = m.group(1)
                    t_num = auto_turn_num(num_str, TITLE_2_FMT)
                else:
                    if is_head:
                        ORDER_SERI_2 += 1
                        num_str = str(ORDER_SERI_2)
                    else:
                        num_str = str(ORDER_SERI_2 + 1)
                    t_num = auto_turn_num(num_str, TITLE_2_FMT)

            return t_num + title_type
        if match.group().startswith('<h'):
            is_head = True
        else:
            is_head = False
        title = re.sub(r'([\d一二两三四五六七八九十百千万壹贰叁肆伍陆柒捌玖拾佰仟萬〇零]+)([{0}])'.format(titletype),func_,match.group())
        if title != match.group():
            #print('转化标题 %s 为 %s '%(match.group(),title))
            return title
        return match.group()

    if RANGE == 0: # 所有页面
        order_list = [mid for mid,linear in bk.getspine()]
    elif RANGE == 1: # 选择页面
        order_list = []
        temp_list = [mid for mimetype,mid in bk.selected_iter()]
        for mid,linear in bk.getspine():
            if mid in temp_list:
                order_list.append(mid)
    for mid in order_list:
            html = bk.readfile(mid)
            html_ = re.sub(r'(?s)<(title|h[1-6])[^>]*>(.*?)</\1>',turn_title_num,html)
            if html_ != html:
                bk.writefile(mid,html_)

class MainWin(QtWidgets.QWidget):
    def __init__(self,bk):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        iconPath = os.path.join(os.path.dirname(__file__),"plugin.png")
        self.setWindowIcon(QtGui.QIcon(iconPath))
        self.init_func()
        self.bk = bk
        self.show()
    
    def init_func(self):
        self.ui.comfirm_btn.clicked.connect(self.comfirm)
        self.ui.cancel_btn.clicked.connect(self.close)

    def comfirm(self):
        global RANGE,TITLETYPE_1,TITLETYPE_2,TITLE_1_FMT,TITLE_2_FMT,RE_ORDER
        TITLETYPE_1 = self.ui.titletype_le_1.text()
        TITLETYPE_2 = self.ui.titletype_le_2.text()
        TITLE_1_FMT = self.ui.fmt_comb_1.currentIndex()
        TITLE_2_FMT = self.ui.fmt_comb_2.currentIndex()

        RANGE = 0 if self.ui.whole_rbtn.isChecked() else 1
        RE_ORDER = False if self.ui.direct_rbtn.isChecked() else True
        main_process(self.bk)
        QtCore.QCoreApplication.instance().quit()
    def reject(self):
        QtCore.QCoreApplication.instance().quit()

def run(bk):
    print('\n  ')
    app = QtWidgets.QApplication(sys.argv)
    win = MainWin(bk)
    app.exec()
    return 0


if __name__ == "__main__":
    from sigil_env import Ebook
    src = "test.epub"
    bk = Ebook(src)
    run(bk)
    #print(cn_turn_arab('两万两千两百'))


