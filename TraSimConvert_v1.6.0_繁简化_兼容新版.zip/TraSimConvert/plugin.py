#!/usr/bin/env python
# -*- coding: utf-8 -*-

import re,sys,os
from util.langconv import Converter 

e = os.environ.get('SIGIL_QT_RUNTIME_VERSION', '6.5.2')
SIGIL_QT_MAJOR_VERSION = tuple(map(int, (e.split("."))))[0]
if SIGIL_QT_MAJOR_VERSION == 6:
    from PySide6 import QtWidgets,QtGui,QtCore
elif SIGIL_QT_MAJOR_VERSION == 5:
    from PyQt5 import QtWidgets,QtGui,QtCore

def Convert(match,LANG):
    text = match.group()
    conv_text = Converter(LANG).convert(text) # LANG = zh-hans | zh-hant
    conv_text.encode('utf-8')
    return conv_text

def hit_convert(LANG:str,is_selected_pages:bool = False):
    if is_selected_pages:
        for id_type,Id in book.selected_iter():
            if id_type == "other" and Id.lower().endswith(".opf"): # When OPF file is selected, id_type is "other" and ID is "OEBPS/xxx.opf"
                metadata = book.getmetadataxml()
                metadata = re.sub(r'<metadata.*?>.*?</metadata>',lambda x:Convert(x,LANG),metadata,0,re.S)
                book.setmetadataxml(metadata)
                continue
            if (book.id_to_mime(Id) not in ["application/xhtml+xml","application/x-dtbncx+xml"]):
                continue
            html = book.readfile(Id)
            html = re.sub(r'<body.*?>.*</body>|<title.*?>.*?</title>|<text>.*?</text>',lambda x:Convert(x,LANG),html,0,re.S)
            book.writefile(Id,html)                 
    else:
        for Id,href in book.text_iter():
            html = book.readfile(Id)
            html = re.sub(r'<body.*?>.*</body>|<title.*?>.*?</title>',lambda x:Convert(x,LANG),html,0,re.S)
            book.writefile(Id,html)
        for Id, href, mime in book.manifest_iter():
            if mime == "application/x-dtbncx+xml":
                html = book.readfile(Id)
                html = re.sub(r'<text>.*?</text>',lambda x:Convert(x,LANG),html,0,re.S)
                book.writefile(Id,html)
        metadata = book.getmetadataxml()
        metadata = re.sub(r'<metadata.*?>.*?</metadata>',lambda x:Convert(x,LANG),metadata,0,re.S)
        book.setmetadataxml(metadata)

class MainUI(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.center()
        self.bind()
        self.show()
    def initUI(self): 
        self.resize(200,150)
        self.setWindowIcon(QtGui.QIcon(os.path.join(os.path.dirname(__file__),'plugin.png')))
        self.setWindowTitle("繁简转化")
        vlayout = QtWidgets.QVBoxLayout(self)
        hlayout1 = QtWidgets.QHBoxLayout()
        hlayout2 = QtWidgets.QHBoxLayout()
        self.tra_pbtn = QtWidgets.QPushButton()
        self.tra_pbtn.setText("繁")
        self.tra_pbtn.setStyleSheet("background-color:#CAC0ED;color:#202020;")
        self.sim_pbtn = QtWidgets.QPushButton()
        self.sim_pbtn.setText("简")
        self.sim_pbtn.setStyleSheet("background-color:#F3E5C3;color:#202020;")
        hlayout1.setSpacing(1)
        hlayout1.setContentsMargins(0,0,0,5)
        for w in [self.tra_pbtn,self.sim_pbtn]:
            w.setFont(QtGui.QFont("STFangsong ",30,100))
            w.setMinimumSize(175,120)
            w.setSizePolicy(QtWidgets.QSizePolicy.Expanding,QtWidgets.QSizePolicy.Expanding)
        hlayout1.addWidget(self.sim_pbtn)
        hlayout1.addWidget(self.tra_pbtn)
        self.curpage_cbox = QtWidgets.QCheckBox(self)
        self.curpage_cbox.setText("仅转换已选择文件")
        self.curpage_cbox.setFont(QtGui.QFont("Simhei",12))
        hlayout2.addWidget(self.curpage_cbox)
        vlayout.addLayout(hlayout1)
        vlayout.addLayout(hlayout2)
    def center(self):
        pt = QtGui.QScreen.availableGeometry(QtWidgets.QApplication.primaryScreen()).center()
        qr = self.frameGeometry()
        qr.moveCenter(pt)
    def bind(self):
        self.sim_pbtn.clicked.connect(self.convert_to_sim)
        self.tra_pbtn.clicked.connect(self.convert_to_tra)
    def convert_to_sim(self):
        self.hide()
        self.setCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
        is_selected = True if self.curpage_cbox.isChecked() else False
        hit_convert('zh-hans',is_selected)
        QtCore.QCoreApplication.instance().quit()
        
    def convert_to_tra(self):
        self.hide()
        self.setCursor(QtGui.QCursor(QtCore.Qt.WaitCursor))
        is_selected = True if self.curpage_cbox.isChecked() else False
        hit_convert('zh-hant',is_selected)
        self.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        QtCore.QCoreApplication.instance().quit()

def run(bk):
    global book
    book = bk
    app = QtWidgets.QApplication(sys.argv)
    ex = MainUI()
    app.exec()
    return 0

    
if __name__ == "__main__":
    from sigil_env import Ebook
    bk = Ebook("test.epub")
    run(bk)
    bk.save_as("test_.epub")