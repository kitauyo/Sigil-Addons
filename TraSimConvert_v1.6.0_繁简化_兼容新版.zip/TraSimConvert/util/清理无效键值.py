from opencc_dict import zh2Hant
from langconv import Converter,registery

MY_MAP = zh2Hant

#这个脚本用于检查繁简转化的映射是否真实有效，
#它的原理很简单，就是分别以一个原始字典和一个复制字典做映射表，以经过排列的键名做待转化文本（字符长度由大到小的顺序排列）。
#然后以原始字典转化一次键名，再从复制字典删去这个键名，再用复制字典映射繁简转化一次，
#如果两次繁简转化的值不同，说明该映射有效，可保留。如果两次转化值相同，说明该映射无效，可以删除。
def sortedDictKeys(mapping):
    temp_ = []
    for key in mapping.keys():
        if len(key) > 1:
            temp_.append(key)
    keys = sorted(temp_,key=len,reverse=True)
    return keys

def test_key():
    invalid_keys = []
    control_dict = MY_MAP.copy()
    registery("zh-hant",MY_MAP)
    registery("test", control_dict)
    converter = Converter("zh-hant")
    test_converter = Converter("test")
    for key in sortedDictKeys(MY_MAP):
        conv_text_1 = converter.convert(key)
        del test_converter.map._map[key] # 删除测试表的键值
        conv_text_2 = test_converter.convert(key)
        if conv_text_1 == conv_text_2:
            print(key)
            invalid_keys.append(key)
    return invalid_keys

def write_ditc_to_py(filename="new_opencc_dict.py",
                     maps = {"zh2Hant":MY_MAP}):
    file_text = ""
    for variant_name,dict_ in maps.items():
        file_text += variant_name +" = "
        file_text += str(dict_)
        file_text += "\n\n"
    file_text = file_text.replace("{","{\n")
    file_text = file_text.replace(", ",",\n")
    file_text = file_text.replace("}","\n}")
    with open(filename,"w",encoding="utf-8") as f:
        f.write(file_text)

invalid_keys = test_key()
for key in invalid_keys:
    del MY_MAP[key]
sorted_map =  { key:MY_MAP[key] for key in sorted(MY_MAP,key=lambda k:k)}
write_ditc_to_py(maps = {"zh2Hant":sorted_map})
